from pymol import cmd, stored, math
	
def Bramp(mol):
    """
    mol = any object selection (within one single object though)
    
    example: Bramp 1LVM and chain A
    """
    obj=cmd.get_object_list(mol)[0]
    stored.bfacts=[]
    
    #iterate (mol), stored.bfacts.append(b)
    #cmd.iterate('(all)', 'stored.bfacts.append(b)')
    cmd.iterate(obj, 'stored.bfacts.append(b)')
    print(min(stored.bfacts),'to',max(stored.bfacts))
    cmd.ramp_new("count", obj, [min(stored.bfacts), max(stored.bfacts)], "rainbow")
    #cmd.label('%s and name CA'%obj,"'%.1f'%b")
    cmd.spectrum("b",selection=obj)
    cmd.recolor()

cmd.extend("Bramp", Bramp);

