from pymol import cmd
from pymol.cgo import *
from glob import glob
import os
try: from supercell import *
except: pass


def goodsell():
    print("""
unset specular
set ray_trace_gain, 0
set ray_trace_mode, 3
bg_color white
set ray_trace_color, black
unset depth_cue
""")


def qutemol():
    print("""
set_color oxygen, [1.0,0.4,0.4]
set_color nitrogen, [0.5,0.5,1.0]
remove solvent
as spheres
util.cbaw
bg white
set light_count,8
set spec_count,1
set shininess, 10
set specular, 0.25
set ambient,0
set direct,0
set reflect,1.5
set ray_shadow_decay_factor, 0.1
set ray_shadow_decay_range, 2
unset depth_cue
# for added coolness
# set field_of_view, 60
ray
""")

cylinder_template = """
obj = [CYLINDER]
obj.extend(%s)
obj.extend(%s)
obj.extend([%f])
obj.extend(%s)
obj.extend(%s)
"""

def scalebar(start, end, radius=3, color=[0.0, 0.0, 0.0], name='scalebar'):
    outstr = ""
    #if not isinstance(start, ndarray): start = array(start)
    #if not isinstance(end, ndarray): end = array(end)
    #start = start.reshape(3).astype('float')
    #end = end.reshape(3).astype('float')
    loA = '[%s]' % ','.join(map(str, start))
    hiB = '[%s]' % ','.join(map(str, end))
    outstr += cylinder_template % (loA, hiB, radius, color, color)
    outstr += "cmd.load_cgo(obj, '%s')" % name
    open('scalebar.pml','w').write(outstr)
    print('Wrote scalebar.pml')

def splitchains(selection,chainlabels):
    for chain in chainlabels:
        print(chain)
        cmd.save('%s.%s.pdb' % (selection,chain), '%s and chain %s' % (selection,chain))
        cmd.load('%s.%s.pdb' % (selection,chain))

def globload(pattern='*.pdb'):
    files = glob(pattern)
    for file in files: cmd.load(file)


def pdblinesplit(line):
    """Parse an ATOM record of a pdb file"""
    if line == '\n': return
    if len(line.split())<2: return
    record = line[:6]
    atomnum = int(line[6:11])
    atomname = line[12:16].strip()
    alternate = line[16]
    resname = line[17:20].strip()
    chain = line[21]
    resnum = int(line[22:26])
    xcoor = float(line[30:38])
    ycoor = float(line[38:46])
    zcoor = float(line[46:54])
    occupancy = line[54:60]
    temp = line[60:66]
    elem = line[76:78]
    charge = line[78:80]
    return record,atomnum,atomname,alternate,resname,chain,resnum,xcoor,ycoor,zcoor,occupancy,temp,elem,charge

def hide_bb_sticks():
  cmd.hide("sticks","name C or name O or (name N and not resn PRO)")

def kk():
  cmd.hide("lines","elem H")
  cmd.show("cartoon")
  cmd.show("spheres","elem Zn or elem Mg or elem Fe or elem Cu")
  cmd.show("sticks","het")

def hideprotein():
  cmd.hide("everything","(resn ALA or resn CYS or resn ASP or resn GLU or resn PHE or resn GLY or resn HIS or resn ILE or resn LYS or resn LEU or resn MET or resn ASN or resn PRO or resn GLN or resn ARG or resn SER or resn THR or resn VAL or resn TRP or resn TYR)")

def showprotein():
  cmd.show("ribbon","(resn ALA or resn CYS or resn ASP or resn GLU or resn PHE or resn GLY or resn HIS or resn ILE or resn LYS or resn LEU or resn MET or resn ASN or resn PRO or resn GLN or resn ARG or resn SER or resn THR or resn VAL or resn TRP or resn TYR)")

def labeldna():
  cmd.label("name C5'", 'chain+resi')

def hidedna():
  cmd.hide("everything","(resn DC or resn DG or resn DA or resn DT)")

def mesh(suffix=''):
  cmd.enable('*mesh')
  cmd.set("ray_trace_mode","0")
  #cmd.set("stick_transparency",0.05,"bbCO")
  #cmd.set("stick_transparency",0.05,"bbN")
  #cmd.show("sticks","bbCO")
  #cmd.show("sticks","bbN")
  cmd.ray(700,1000)
  cmd.png("mesh%s.png"%suffix,dpi=600)

def outline(suffix=''):
  #cmd.disable('adductmesh')
  cmd.disable('*mesh')
  #cmd.hide("sticks","bb")
  cmd.set("ray_trace_mode","1")
  cmd.ray(700,1000)
  cmd.png("outline%s.png"%suffix,dpi=600)

def showdna():
  cmd.show("ribbon","(resn DC or resn DG or resn DA or resn DT)")

def hide_bb_lines():
  cmd.hide("lines","name C or name O or (name N and not resn PRO)")

def hide_bb():
  cmd.hide("sticks","name C or name O or (name N and not resn PRO)")
  cmd.hide("lines","name C or name O or (name N and not resn PRO)")

def max_cartoon():
  cmd.hide("everything")
  cmd.set("cartoon_cylindrical_helices","on")
  cmd.set("cartoon_helix_radius",1.5)
  cmd.set("cartoon_smooth_loops","on")
  cmd.set("cartoon_flat_sheets","on")
  cmd.set("cartoon_discrete_colors","on")
  cmd.color("wheat","ss l+")
  cmd.color("raspberry","ss h")
  cmd.color("orange","ss s")
  cmd.show("cartoon")

def color_chimera_blocks(*recombsites):
  if recombsites == []:
    print('Usage: color_chimera_blocks(A,B,C,D...N)')
    return None
  print(recombsites)
  print('Creating',len(recombsites)+1,'blocks')
  index = 1
  lastres = 1
  for initres in recombsites:
    X = int(initres)-1
    cmd.select('block%d'%index, 'resi %d-%d'%(lastres,X) )
    index += 1
    lastres = initres
  cmd.select('block%d'%index, 'resi %d-%d'%(lastres,9999))
  
  if len(recombsites)==7:
    cmd.color('red', 'block1') 
    cmd.color('orange', 'block2') 
    cmd.color('yellow', 'block3') 
    cmd.color('green', 'block4') 
    cmd.color('greencyan', 'block5') 
    cmd.color('tv_blue', 'block6') 
    cmd.color('violetpurple', 'block7') 
    cmd.color('gray70', 'block8') 

def calc_resi2pos(pdb):
  resi2pos = {}
  lines = open(pdb).readlines()
  for line in lines:
    if line[:4] != 'ATOM': continue
    record,atomnum,atomname,alternate,resname,chain,resnum,xcoor,ycoor,zcoor,occupancy,temp,elem,charge = pdblinesplit(line)
    if atomname == 'CB':
      resi2pos[resnum] = [xcoor,ycoor,zcoor] 
    elif atomname == 'CA' and resname == 'GLY': 
      resi2pos[resnum] = [xcoor,ycoor,zcoor] 
  return resi2pos

def parse_schema_contactfile(contactfile):
  contacts = []
  lines = open(contactfile).readlines()
  for line in lines:
    if line[0] == '#': continue
    l = line.split()
    contacts.append((int(l[3]),int(l[4])))
  return contacts

def view_all_schema_contacts(pdb,contactfile):
  resi2pos = calc_resi2pos(pdb)
  contacts = parse_schema_contactfile(contactfile)
  thick,Rgb1,rGb1,rgB1,Rgb2,rGb2,rgB2 = 0.1, 1, 0.5, 0, 1, 0.5, 0;
  cgoOBJ = []
  for i,j in contacts:
    posi,posj = resi2pos[i],resi2pos[j]
    xi,yi,zi = posi
    xj,yj,zj = posj
    values = (xi,yi,zi,xj,yj,zj,thick,Rgb1,rGb1,rgB1,Rgb2,rGb2,rgB2)
    obj = [CYLINDER,xi,yi,zi,xj,yj,zj,thick,Rgb1,rGb1,rgB1,Rgb2,rGb2,rgB2]
    cgoOBJ.extend(obj)
  cmd.load_cgo(cgoOBJ,'contacts')

def view_novel_schema_contacts(pdb,contactspy):
  resi2pos = calc_resi2pos(pdb)
  exec('from %s import novelcontacts'%contactspy)
  contacts = novelcontacts.keys() 
  thick,Rgb1,rGb1,rgB1,Rgb2,rGb2,rgB2 = 0.1, 1, 0.5, 0, 1, 0.5, 0;
  cgoOBJ = []
  for i,j in contacts:
    posi,posj = resi2pos[i],resi2pos[j]
    xi,yi,zi = posi
    xj,yj,zj = posj
    values = (xi,yi,zi,xj,yj,zj,thick,Rgb1,rGb1,rgB1,Rgb2,rGb2,rgB2)
    obj = [CYLINDER,xi,yi,zi,xj,yj,zj,thick,Rgb1,rGb1,rgB1,Rgb2,rGb2,rgB2]
    cgoOBJ.extend(obj)
  cmd.load_cgo(cgoOBJ,'contacts')

def blob(obj):
    #cmd.set('gaussian_b_floor', 50)
    cmd.set('gaussian_b_floor', 50)
    cmd.set('gaussian_resolution', 8)
    mapname = 'map.%s'%str(obj)
    surfname = 'surf.%s'%str(obj)
    #cmd.map_new(mapname,'gaussian', grid=3, selection=obj, buffer=10)
    cmd.map_new(mapname,'gaussian', grid=1, selection=obj, buffer=10)
    cmd.isosurface(surfname,mapname,1.0)

def maxcartoon():
   cmd.bg_color('white')
   cmd.set('''opaque_background''','''0''',quiet=0)
   cmd.set('''cartoon_cylindrical_helices''','''1''',quiet=0)
   cmd.set('''cartoon_smooth_loops''','''1''',quiet=0)
   cmd.color('wheat')
   cmd.color('raspberry', 'ss h')
   cmd.color('orange', 'ss s')
   cmd.orient()

def aligned_view():
    '''Align the camera view with the molecule axes'''
    _, _, _, _, _, _, _, _, _, v10, v11, v12, v13, v14, v15, v16, v17, v18 = cmd.get_view()
    cmd.set_view("1, 0, 0, 0, 1, 0, 0, 0, 1," + ','.join(map(str, [v10, v11, v12, v13, v14, v15, v16, v17, v18])))

def align2_view():
    '''Align the camera view with the molecule axes'''
    _, _, _, _, _, _, _, _, _, v10, v11, v12, v13, v14, v15, v16, v17, v18 = cmd.get_view()
    cmd.set_view("1, 0, 0, 0, 0, 1, 0, 1, 0," + ','.join(map(str, [v10, v11, v12, v13, v14, v15, v16, v17, v18])))

def align3_view():
    '''Align the camera view with the molecule axes'''
    _, _, _, _, _, _, _, _, _, v10, v11, v12, v13, v14, v15, v16, v17, v18 = cmd.get_view()
    cmd.set_view("0, 1, 0, 1, 0, 0, 0, 0, 1," + ','.join(map(str, [v10, v11, v12, v13, v14, v15, v16, v17, v18])))

def monoclinic_view():
    '''Align the camera view down the y axis with the z axis horizontal'''
    _, _, _, _, _, _, _, _, _, v10, v11, v12, v13, v14, v15, v16, v17, v18 = cmd.get_view()
    cmd.set_view("0, 1, 0, 0, 0, 1, 1, 0, 0," + ','.join(map(str, [v10, v11, v12, v13, v14, v15, v16, v17, v18])))

def align4_view():
    '''Align the camera view with the molecule axes'''
    _, _, _, _, _, _, _, _, _, v10, v11, v12, v13, v14, v15, v16, v17, v18 = cmd.get_view()
    cmd.set_view("0, 0, 1, 1, 0, 0, 0, 1, 0," + ','.join(map(str, [v10, v11, v12, v13, v14, v15, v16, v17, v18])))

def align5_view():
    '''Align the camera view with the molecule axes'''
    _, _, _, _, _, _, _, _, _, v10, v11, v12, v13, v14, v15, v16, v17, v18 = cmd.get_view()
    cmd.set_view("0, 0, 1, 0, 1, 0, 1, 0, 0," + ','.join(map(str, [v10, v11, v12, v13, v14, v15, v16, v17, v18])))

def kc():
    cmd.run('general.pml')
    showscripts = glob('show.*.py')
    for name in cmd.get_names():
        if name.endswith('named'): 
            root = name.split('.')[0]
    #if len(showscripts)==1:
    #    cmd.run(showscripts[0])
        cmd.run('show.%s.py'%root)
    #cmd.hide('spheres','hole*')
        cmd.orient('%s.named'%root)
        cmd.deselect()

def invert():
    cmd.select('nowvisible','visible')
    cmd.show('spheres', '*.named')
    cmd.hide('spheres', 'nowvisible')
    cmd.deselect()
    cmd.delete('nowvisible')

    activethings = cmd.get_names(enabled_only=1)
    for name in cmd.get_names():
        if name in activethings and '_' in name:
            print('Disabling',name)
            cmd.disable(name)
        else:
            print('Enabling',name)
            cmd.enable(name)
            if name.startswith('bend'):
                cmd.show('spheres',name)
            
        
def hb():
    cmd.disable('b*')

def sh():
    cmd.enable('hole*')

def hh():
    cmd.disable('hole*')

def sb():
    cmd.enable('b*')

def sl():
    cmd.show('lines','*.named')

def ss():
    cmd.show('spheres','sele')

def hs():
    cmd.hide('spheres','sele')

def hl():
    cmd.hide('lines','*.named')

def aa():
    cmd.enable('*')
    cmd.disable('hole*')
    cmd.show('spheres','*')
    cmd.deselect()

def rr():
    cmd.ray(3300,2000)

def r2():
    cmd.ray(2000,2000)

def r33():
    cmd.ray(3000,3000)

def rbig():
    cmd.ray(4000,2400)

def hdhd():
    '''Hide the current selection, as well as associated CGO. KidChem project'''
    cmd.save('tmptmp.pdb','(sele)')
    cmd.hide('spheres','(sele) and not hole*')
    cmd.disable('(sele) and hole*')
    atoms = set()
    for line in open('tmptmp.pdb','r').readlines():
        if len(line)<6: continue
        if line[:6] not in ['ATOM  ','HETATM']: continue
        aname = line[12:16].strip()
        if 'PS' in aname: continue
        atoms.add(aname)
    for name in cmd.get_names():
        #if name.endswith('named'): continue
        if '_' not in name: continue
        namelist = name.split('_')
        if atoms.issuperset(namelist[1:]):
            cmd.disable(name)
        elif atoms.intersection(namelist[1:]):
            print('Interfacial object', name)
            if name.startswith('bend'):
                cmd.show('spheres',name)
            if name.startswith('hole') and namelist[-1] in atoms:
                cmd.disable(name)
     
    print(atoms)

def isolate():
    '''Hide all but the selection and associated CGO. Enable interfacial holes. KidChem project'''

    print('Enabling holes')
    cmd.enable('hole*')

    print('Figuring out the atoms in (sele)')
    atoms = set()
    cmd.save('tmptmp.pdb','(sele)')
    for line in open('tmptmp.pdb','r').readlines():
        if len(line)<6: continue
        if line[:6] not in ['ATOM  ','HETATM']: continue
        aname = line[12:16].strip()
        if 'PS' in aname: continue
        atoms.add(aname)

    print('atoms in (sele) are:', ','.join(atoms)) 
    cmd.hide('spheres','not (sele) and not hole*')

    for name in cmd.get_names():
        #if name.endswith('named'): continue
        if '_' not in name: continue
        if name.endswith('.named'): continue
        namelist = name.split('_')
        if atoms.issuperset(namelist[1:]):
            ## make sure we don't lose any bendy bond bits within the selection
            if name.startswith('bend'):
                print('Ensuring all sphere in %s are visible' % name)
                cmd.show('spheres',name)
        elif atoms.intersection(namelist[1:]):
            if namelist[0].startswith('hole') and namelist[-1] in atoms:
                print('Ensuring interfacial hole on the %s side is visible' % namelist[-1])
                cmd.enable(name)
            else:
                ## disable bonds that are not entirely within the selection
                cmd.disable(name)
                if name.startswith('bend'):
                    cmd.hide('spheres',name)
        else:
            ## disable bonds that are entirely outside the selection
            cmd.disable(name)
            #    cmd.enable(name)
   
def haha():
    '''Hide bonds within the current selection, as well as associated CGO. KidChem project'''
    cmd.save('tmptmp.pdb','(sele)')
    atoms = set()
    for line in open('tmptmp.pdb','r').readlines():
        if len(line)<6: continue
        if line[:6] not in ['ATOM  ','HETATM']: continue
        aname = line[12:16].strip()
        if 'PS' in aname: continue
        atoms.add(aname)
    for name in cmd.get_names():
        #if name.endswith('named'): continue
        if '_' not in name: continue
        namelist = name.split('_')
        if atoms.issuperset(namelist[1:]):
            cmd.disable(name)
            if namelist[0].startswith('hole'):
                cmd.enable(name)
        elif atoms.intersection(namelist[1:]):
            print('Interfacial object', name)
            if name.startswith('bend'):
                cmd.show('spheres',name)
     
    print(atoms)
   
def hjhj():
    '''Hide bonds within the current selection, as well as associated CGO. KidChem project'''
    cmd.save('tmptmp.pdb','(sele)')
    atoms = set()
    for line in open('tmptmp.pdb','r').readlines():
        if len(line)<6: continue
        if line[:6] not in ['ATOM  ','HETATM']: continue
        aname = line[12:16].strip()
        if 'PS' in aname: continue
        atoms.add(aname)
    for name in cmd.get_names():
        #if name.endswith('named'): continue
        if '_' not in name: continue
        namelist = name.split('_')
        if atoms.issuperset(namelist[1:]):
            cmd.disable(name)
        elif atoms.intersection(namelist[1:]):
            print('Interfacial object', name)
            if name.startswith('bend'):
                cmd.show('spheres',name)
     
    print(atoms)
   

def cgo_arrow(atom1='pk1', atom2='pk2', radius=0.5, gap=0.0, hlength=-1, hradius=-1,
              color='blue red', name=''):
    '''
DESCRIPTION

    Create a CGO arrow between two picked atoms.

ARGUMENTS

    atom1 = string: single atom selection or list of 3 floats {default: pk1}

    atom2 = string: single atom selection or list of 3 floats {default: pk2}

    radius = float: arrow radius {default: 0.5}

    gap = float: gap between arrow tips and the two atoms {default: 0.0}

    hlength = float: length of head

    hradius = float: radius of head

    color = string: one or two color names {default: blue red}

    name = string: name of CGO object
    '''
    from chempy import cpv

    radius, gap = float(radius), float(gap)
    hlength, hradius = float(hlength), float(hradius)

    try:
        color1, color2 = color.split()
    except:
        color1 = color2 = color
    color1 = list(cmd.get_color_tuple(color1))
    color2 = list(cmd.get_color_tuple(color2))

    def get_coord(v):
        if not isinstance(v, str):
            return v
        if v.startswith('['):
            return cmd.safe_list_eval(v)
        return cmd.get_atom_coords(v)

    xyz1 = get_coord(atom1)
    xyz2 = get_coord(atom2)
    normal = cpv.normalize(cpv.sub(xyz1, xyz2))

    if hlength < 0:
        hlength = radius * 3.0
    if hradius < 0:
        hradius = hlength * 0.6

    if gap:
        diff = cpv.scale(normal, gap)
        xyz1 = cpv.sub(xyz1, diff)
        xyz2 = cpv.add(xyz2, diff)

    xyz3 = cpv.add(cpv.scale(normal, hlength), xyz2)

    obj = [cgo.CYLINDER] + xyz1 + xyz3 + [radius] + color1 + color2 + \
          [cgo.CONE] + xyz3 + xyz2 + [hradius, 0.0] + color2 + color2 + \
          [1.0, 0.0]

    if not name:
        name = cmd.get_unused_name('arrow')

    cmd.load_cgo(obj, name)

## Expose to the pymol command line
cmd.extend("blob",blob)
cmd.extend("color_chimera_blocks",color_chimera_blocks)
cmd.extend("hdhd",hdhd)
cmd.extend("haha",haha)
cmd.extend("hjhj",hjhj)
cmd.extend("kc",kc)
cmd.extend("hb",hb)
cmd.extend("sb",sb)
cmd.extend("ss",ss)
cmd.extend("hs",hs)
cmd.extend("sl",sl)
cmd.extend("hl",hl)
cmd.extend("rr",rr)
cmd.extend("r2",r2)
cmd.extend("rbig",rbig)
cmd.extend("r33",r33)
cmd.extend("max_cartoon",max_cartoon)
cmd.extend("showprotein",showprotein)
cmd.extend("showdna",showdna)
cmd.extend("labeldna",labeldna)
cmd.extend("hideprotein",hideprotein)
cmd.extend("hidedna",hidedna)
cmd.extend("hide_bb_sticks",hide_bb_sticks)
cmd.extend("hide_bb_lines",hide_bb_lines)
cmd.extend("hide_bb",hide_bb)
cmd.extend("view_all_schema_contacts",view_all_schema_contacts)
cmd.extend("view_novel_schema_contacts",view_novel_schema_contacts)
cmd.extend("loadglob",globload)
cmd.extend("globload",globload)
cmd.extend("splitchains",splitchains)
cmd.extend('cgo_arrow', cgo_arrow)
cmd.extend('aligned_view', aligned_view)
cmd.extend('align2_view', align2_view)
cmd.extend('align3_view', align3_view)
cmd.extend('align4_view', align4_view)
cmd.extend('align5_view', align5_view)
cmd.extend('monoclinic_view', monoclinic_view)
cmd.extend('qutemol', qutemol)
cmd.extend('mesh', mesh)
cmd.extend('outline', outline)
cmd.extend('kk', kk)
cmd.extend('sh', sh)
cmd.extend('hh', hh)
cmd.extend('aa', aa)
cmd.extend('invert',invert)
cmd.extend('isolate',isolate)
cmd.extend('scalebar',scalebar)
