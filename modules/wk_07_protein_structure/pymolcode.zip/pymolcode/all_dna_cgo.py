from pymol import cmd
import numpy as np
from collections import defaultdict

def get_dna_positions(object_name):
    """Extract C1' and C3' positions."""
    c1_model = cmd.get_model(f"{object_name} and name C1'")
    c3_model = cmd.get_model(f"{object_name} and name C3'")
    
    positions = defaultdict(dict)
    metadata = []
    c1_coords = []
    
    for atom in c1_model.atom:
        if atom.resn in ['DA', 'DT', 'DG', 'DC']:
            idx = len(metadata)
            positions[atom.chain][atom.resi] = {
                'C1': np.array([atom.coord[0], atom.coord[1], atom.coord[2]]),
                'index': idx
            }
            c1_coords.append([atom.coord[0], atom.coord[1], atom.coord[2]])
            metadata.append({
                'chain': atom.chain,
                'resi': atom.resi,
                'resn': atom.resn
            })
    
    for atom in c3_model.atom:
        if atom.resn in ['DA', 'DT', 'DG', 'DC']:
            if atom.chain in positions and atom.resi in positions[atom.chain]:
                positions[atom.chain][atom.resi]['C3'] = np.array([atom.coord[0], atom.coord[1], atom.coord[2]])
    
    return positions, metadata, np.array(c1_coords)

def calculate_angle(v1, v2):
    """Calculate angle between vectors in degrees."""
    dot = np.dot(v1, v2)
    norms = np.linalg.norm(v1) * np.linalg.norm(v2)
    return np.degrees(np.arccos(np.clip(dot/norms, -1.0, 1.0)))

def find_wc_pairs(positions, metadata, max_distance=11.0, angle_target=152.6, angle_tolerance=10):
    """Find Watson-Crick paired bases using C1' distances and C3'-C1'-C1' angles."""
    pairs = []
    for chain1 in positions:
        for chain2 in positions:
            if chain1 >= chain2:
                continue
            
            for resi1, pos1 in positions[chain1].items():
                for resi2, pos2 in positions[chain2].items():
                    if 'C3' not in pos1 or 'C3' not in pos2:
                        continue
                        
                    dist = np.linalg.norm(pos1['C1'] - pos2['C1'])
                    if dist <= max_distance:
                        # Calculate C3'-C1'-C1' angles
                        v1 = pos1['C3'] - pos1['C1']
                        v2 = pos2['C1'] - pos1['C1']
                        v3 = pos2['C3'] - pos2['C1']
                        v4 = pos1['C1'] - pos2['C1']
                        
                        angle1 = calculate_angle(v1, v2)
                        angle2 = calculate_angle(v3, v4)
                        
                        if (abs(angle1 - angle_target) <= angle_tolerance and 
                            abs(angle2 - angle_target) <= angle_tolerance):
                            # Check if either base is already paired
                            if not any(i in [p[0] for p in pairs] or i in [p[1] for p in pairs] for i in [pos1['index'], pos2['index']]):
                                pairs.append((pos1['index'], pos2['index']))
    
    # Print first 10 WC pairs for debugging
    print(f"\nFirst 10 WC pairs:")
    for i, j in sorted(pairs, key=lambda x: int(metadata[x[0]]['resi']))[:10]:
        print(f"{metadata[i]['chain']}{metadata[i]['resi']} - {metadata[j]['chain']}{metadata[j]['resi']}")
    print(f"\nFound {len(pairs)} total WC-paired bases")
    return pairs

def find_paired_regions(pairs, metadata):
    """Group consecutive WC pairs into regions by chain pairs."""
    # Group pairs by chain combination
    chain_groups = defaultdict(list)
    for i, j in pairs:
        chain_key = f"{metadata[i]['chain']}-{metadata[j]['chain']}"
        chain_groups[chain_key].append((i, j))
    
    paired_regions = []
    for chain_key, chain_pairs in chain_groups.items():
        sorted_pairs = sorted(chain_pairs, key=lambda x: int(metadata[x[0]]['resi']))
        
        current_region = []
        for i, j in sorted_pairs:
            if not current_region:
                current_region = [(i, j)]
            else:
                prev_i, prev_j = current_region[-1]
                delta_i = int(metadata[i]['resi']) - int(metadata[prev_i]['resi'])
                delta_j = int(metadata[j]['resi']) - int(metadata[prev_j]['resi'])
                
                if delta_i == 1 and delta_j == -1:
                    current_region.append((i, j))
                else:
                    if len(current_region) >= 3:
                        paired_regions.append(current_region)
                        print(f"Found region of length {len(current_region)} in {chain_key}")
                    current_region = [(i, j)]
        
        if current_region and len(current_region) >= 3:
            paired_regions.append(current_region)
            print(f"Found region of length {len(current_region)} in {chain_key}")
    
    return paired_regions

def draw_dna_cylinders(object_name, paired_regions, positions, metadata, window_size=6, radius=10):
    """Draw CGO cylinders along DNA helical axes."""
    from pymol import cgo
    from pymol.cgo import COLOR, CYLINDER, ALPHA
    
    for region in paired_regions:
        # Get C1' coordinates for each base pair
        bp_centers = []
        for i, j in region:
            pos1 = positions[metadata[i]['chain']][metadata[i]['resi']]['C1']
            pos2 = positions[metadata[j]['chain']][metadata[j]['resi']]['C1']
            center = (pos1 + pos2) / 2
            bp_centers.append(center)
        
        bp_centers = np.array(bp_centers)
        
        # Compute overall helical axis using PCA
        mean_pos = np.mean(bp_centers, axis=0)
        centered_coords = bp_centers - mean_pos
        cov_matrix = np.dot(centered_coords.T, centered_coords)
        eigenvals, eigenvecs = np.linalg.eig(cov_matrix)
        helical_axis = eigenvecs[:, np.argmax(eigenvals)]
        
        # Get first and last base pair centers
        first_center = bp_centers[0]
        last_center = bp_centers[-1]
        
        # Project endpoints onto helical axis
        first_proj = project_point_on_vector(first_center - mean_pos, helical_axis) + mean_pos
        last_proj = project_point_on_vector(last_center - mean_pos, helical_axis) + mean_pos
        
        # Create CGO cylinder
        obj = [
            cgo.CYLINDER,
            float(first_proj[0]), float(first_proj[1]), float(first_proj[2]),
            float(last_proj[0]), float(last_proj[1]), float(last_proj[2]),
            radius,  # radius
            1.0, 0.5, 0,  # color1 (white)
            1.0, 0.5, 0,  # color2 (white)
        ]
        
        # Create unique name for each cylinder
        i1, j1 = region[0]
        i2, j2 = region[-1]
        cyl_name = f"{object_name}_helix_{metadata[i1]['chain']}{metadata[i1]['resi']}-{metadata[i2]['chain']}{metadata[i2]['resi']}"
        cmd.load_cgo(obj, cyl_name)

def project_point_on_vector(point, vector):
    """Project a point onto a vector."""
    vector = vector / np.linalg.norm(vector)
    return np.dot(point, vector) * vector
    

def analyze_dna_all_objects():
    for obj in cmd.get_object_list():
        print(f"\nAnalyzing object: {obj}")
        positions, metadata, c1_coords = get_dna_positions(obj)
        pairs = find_wc_pairs(positions, metadata)
        paired_regions = find_paired_regions(pairs, metadata)
        if paired_regions:
            draw_dna_cylinders(obj, paired_regions, positions, metadata)
        else:
            print("No paired regions found")

cmd.extend('all_dna_cgo', analyze_dna_all_objects)
